<?php 
include_once("header.php");
include_once(get_template_directory() . "/templates/single-gallery.php");
include_once("footer.php");
?>