<div id="container_box_proximas_travesias" style="display: none">

    <div class="buttons_modal">
        <a href="#" class="selected">Travesías programadas</a>
        <a href="#">Travesías para grupos</a>
        <a href="#">Travesías para empresas</a>
    </div>

    <div class="container_papers">

        <div class="travesias_programadas paper">
            <h3>Travesías programadas</h3>
            <table cellspacing="0" cellpadding="0">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td>Test</td>
                        <td>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla perspiciatis necessitatibus dolore</td>
                        <td>21/12/2020</td>
                    </tr>

                    <tr>
                        <td>Test 2</td>
                        <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia sint officiis, debitis nemo expedita veritatis ipsam cum velit maxime doloribus id saepe dolore. Eos quia hic, voluptatum corporis dolor blanditiis!</td>
                        <td>25/12/2020</td>
                    </tr>

                </tbody>
            </table>
        </div>

        <div class="travesias_a_medida paper">
            <h3>Travesías a medida para grupos</h3>
        </div>

        <div class="travesias_empresas paper">
            <h3>Travesías para empresas</h3>
        </div>

    </div>

</div>

<div id="container_box_proximas_travesias_mobile" style="display: none">



</div>