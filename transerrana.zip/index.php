<?php 
include_once("header.php");
include_once(get_template_directory() . "/templates/slider.php");
include_once(get_template_directory() . "/templates/sobre-nosotros.php");
include_once(get_template_directory() . "/templates/gallery.php");
include_once(get_template_directory() . "/templates/paseos.php");
include_once(get_template_directory() . "/templates/citas.php");
include_once(get_template_directory() . "/templates/equipo.php");
include_once("footer.php");
?>